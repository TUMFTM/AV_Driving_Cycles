%% Description: running ACC simulation with parameters
% Designed by: Duan, Xucheng (FTM, Technical University of Munich)
%-------------
% Created on: 20.08.2021
% Last update: 26.08.2021
% ------------
% Version: Matlab2020b
%-------------
% Description: running ACC simulation with parameters
% ------------
% Input:    - Para: Struct of parameters for the simulation and ACC-controller
%
% ------------
% Output:   - simOut: output from Simulink
%           - Eval: Struct of properties for evaluation
% ------------
% References:   - [1] Skript - VL Fahrerassistanzsystem
%               - [2] H. Winner, S. Hakuli, F. Lotz, und C. Singer, 
%                     Handbuch Fahrerassistenzsysteme: Grundlagen, Komponenten und Systeme für aktive Sicherheit und Komfort, 
%                     3rd Aufl. Wiesbaden: Springer Vieweg, 2015.
%                     Chap. 46 - Adaptive Cruise Control
%%-------------
clear variables;

savename = 'stepwise_p'; % name for saving workspace

%% default parameters
Para.speed_set = 120;         % ACC set speed [km/h]
Para.t_set	 = 2;             % time headway [s]
Para.d0      = 4;             % constant distance [m]
Para.P_a_x   = [-100,0,100];  % [m/s]
Para.P_a_y   = [-70,0,70];    % [m/s^2]
Para.P_v_x   = [-100,0,100];  % [m]
Para.P_v_y   = [-7,0,7];      % [m/s]

%% override parameters
Para.speed_set = 120;
Para.P_a_x   = [-10,0,10];  % [m/s]
Para.P_a_y   = [-7,0,7];    % [m/s^2]
Para.P_v_x   = [-100,0,100];  % [m]
Para.P_v_y   = [-7,0,7];      % [m/s]
Para.P_a_x   = [-10,-2,0,2,10];  % [m/s]
Para.P_a_y   = [-7,-1,0,1,7];    % [m/s^2]


%% run simulation model
simdl = 'Cascade_ACC_Para'; 
open_system(simdl)
mdlWks = get_param(simdl,'ModelWorkspace');
Para_list = fieldnames(Para);
for i = 1:length(Para_list)
    assignin(mdlWks,Para_list{i},Para.(Para_list{i}))
end
simOut = sim(simdl);

%% results evalutation
% load logged signals
log_list = simOut.logsout.getElementNames;
Logs = struct;
for i = 1:length(log_list)
    Logs.(log_list{i}) = simOut.logsout{i}.Values;
end
Logs.v_rel = Logs.v_front - Logs.v_ego;
clear log_list
clear i

if Logs.AEB_triggered.data(end) > 0
    warning('AEB is triggered during the simulation!')
end

% evalutation
Eval.a_max = max(Logs.a_ego);   % max accelerlation [m/s^2]
Eval.a_min = min(Logs.a_ego);   % max deceleration [m/s^2]
Eval.a_RMS = rms(Logs.a_ego.Data);  % RMS accerlation
Eval.j_max = max(Logs.jerk);    % max positive jerk [m/s^3]
Eval.j_min = min(Logs.jerk);    % max negative jerk [m/s^3]
Eval.j_RMS = rms(Logs.jerk.Data);   % RMS jerk
%Eval.x_rel_min = min(Logs.x_rel);  % min distance [m]
Eval.t_rel_min = min(Logs.x_rel ./ Logs.v_ego); % min time headway [s]
Eval.TTC_min = min(Logs.TTC);   % min Time-to-Collision [s]
Eval

% save mat
save(['./ACC_Data/',savename,'_',datestr(now,'yymmdd')])